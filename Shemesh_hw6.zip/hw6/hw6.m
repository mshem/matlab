% Michael Shemesh
% 4/5/2015
% hw6 

% Problem 1
polyadd([2 0 -3 -9 11 -8 4], [5 0 7 -10], 'add')
polyadd([2 0 -3 -9 11 -8 4], [5 0 7 -10], 'sub')
% Problem 2
polymult([2 0 -3 -9 11 -8 4], [5 0 7 -10])
conv([2 0 -3 -9 11 -8 4], [5 0 7 -10])
% Problem 3
problem3
