function s = taylorsin(x)
s=taylorcos(x-90);
end